package com.hexaware.Career.Enum;

public enum ApplicationStatus {
    APPLIED,
    REVIEWED,
    SELECTED,
    REJECTED
}
