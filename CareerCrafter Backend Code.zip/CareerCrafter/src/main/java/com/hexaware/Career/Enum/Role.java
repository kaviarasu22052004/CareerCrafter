package com.hexaware.Career.Enum;

public enum Role {
    ROLE_EMPLOYER,
    ROLE_JOBSEEKER,
    ADMIN
}
